import SwiftUI
import UIKit

/// Line 24 visual system — tokens from Figma UI kit (navy / danger / Inter ramp via SF).
enum CivicTheme {
    static let canvas = Color.white
    static let vetoCanvas = Color.white
    static let surface = Color.white
    /// Headings / primary text `#010F17`
    static let ink = Color(red: 1 / 255, green: 15 / 255, blue: 23 / 255)
    /// Secondary `#5B617F`
    static let muted = Color(red: 91 / 255, green: 97 / 255, blue: 127 / 255)
    /// Primary Dark Navy `#08324A`
    static let accent = Color(red: 8 / 255, green: 50 / 255, blue: 74 / 255)
    /// Tile labels `#292B3D`
    static let textPrimary = Color(red: 41 / 255, green: 43 / 255, blue: 61 / 255)
    /// Feedback / emergency `#801717`
    static let danger = Color(red: 128 / 255, green: 23 / 255, blue: 23 / 255)
    /// Voice-on accent `#0E7B46`
    static let success = Color(red: 14 / 255, green: 123 / 255, blue: 70 / 255)
    /// Kept for rare emphasis; kit prefers navy for veto CTAs
    static let warning = Color(red: 0.95, green: 0.72, blue: 0.08)
    static let antiFill = danger.opacity(0.06)
    static let antiBorder = danger.opacity(0.2)
    static let barFill = Color.white
    /// Navy @ 6%
    static let secondaryFill = accent.opacity(0.06)
    static let border = accent.opacity(0.2)

    static let corner: CGFloat = 16
    static let buttonCorner: CGFloat = 16
    static let pillCorner: CGFloat = 10

    static let voiceFont = Font.system(size: 28, weight: .semibold)
    static let helperFont = Font.system(size: 17, weight: .medium)
    static let buttonFont = Font.system(size: 20, weight: .bold)
    static let badgeFont = Font.system(size: 15, weight: .semibold)
    static let emergencyLabel = Font.system(size: 15, weight: .semibold)
    static let emergencyTitle = Font.system(size: 20, weight: .bold)
    static let typeLabelFont = Font.system(size: 15, weight: .semibold)
}

struct NodeFrameView: View {
    @ObservedObject var engine: ProtocolEngine
    @ObservedObject var speech: SpeechController
    @Binding var speakOnAppear: Bool
    var onSelect: ((String) -> Void)?
    var onOpenLastReport: (() -> Void)?

    @State private var showSettings = false

    private var isVeto: Bool { engine.currentNode.veto }

    var body: some View {
        Group {
            if showSettings {
                SettingsView(
                    locale: $engine.locale,
                    speakOnAppear: $speakOnAppear,
                    onClose: { showSettings = false }
                )
            } else {
                protocolFrame
            }
        }
    }

    /// Home / Type / Form / Give: title + body + actions share one ScrollView.
    /// Other screens: body top, actions docked above 103.
    private var docksActionsAtBottom: Bool {
        switch engine.currentNode.id {
        case "Home", "Type", "Form", "Give":
            return false
        default:
            return true
        }
    }

    private var protocolFrame: some View {
        VStack(spacing: 0) {
            topBar

            if docksActionsAtBottom {
                ScrollView {
                    protocolContentStack
                        .padding(.horizontal, 24)
                        .padding(.top, 8)
                        .padding(.bottom, 16)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)

                protocolActionsStack
                    .padding(.horizontal, 24)
                    .padding(.top, 8)
                    .padding(.bottom, 12)
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        protocolContentStack
                        protocolActionsStack
                        if engine.currentNode.id == "Home",
                           let summary = engine.lastEventSummaryLine
                        {
                            lastEventCard(summary)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 8)
                    .padding(.bottom, 24)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }

            EmergencyBar(
                locale: engine.locale,
                show101: engine.showsRescue101,
                prioritize101: engine.prioritize101,
                emphasizeCall: engine.currentNode.id == "Call"
            ) { number in
                dial(number)
            }
        }
        .background(screenBackground)
        .ignoresSafeArea(edges: .bottom)
        .onAppear { speakCurrent() }
        .onChange(of: engine.currentNode.id) { _ in
            speech.stopDictation()
            speakCurrent()
        }
        .onChange(of: engine.manualLocationFieldIndex) { _ in
            if engine.isManualLocationEntry {
                speakCurrent()
            }
        }
        .onChange(of: engine.locale) { newLocale in
            AppPreferences.locale = newLocale
            speakCurrent()
        }
    }

    @ViewBuilder
    private var protocolContentStack: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(engine.voiceText)
                .font(CivicTheme.voiceFont)
                .foregroundStyle(CivicTheme.ink)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)

            if let helper = engine.helperText {
                Text(helper)
                    .font(.system(size: 19, weight: .medium))
                    .foregroundStyle(CivicTheme.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if let anti = engine.antiPatternText {
                Label(anti, systemImage: "exclamationmark.triangle.fill")
                    .font(.body.weight(.bold))
                    .foregroundStyle(CivicTheme.danger)
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(
                        CivicTheme.antiFill,
                        in: RoundedRectangle(cornerRadius: CivicTheme.corner)
                    )
                    .overlay {
                        RoundedRectangle(cornerRadius: CivicTheme.corner)
                            .stroke(CivicTheme.antiBorder, lineWidth: 1)
                    }
            }

            if engine.showsBrigadeReportCard {
                brigadeReportCard
            } else if let detail = engine.detailBlock {
                Text(detail)
                    .font(engine.currentNode.id == "Loc-2"
                          ? .system(size: 26, weight: .bold, design: .rounded)
                          : .system(size: 22, weight: .semibold))
                    .foregroundStyle(CivicTheme.ink)
                    .lineSpacing(4)
                    .padding(18)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(
                        CivicTheme.secondaryFill,
                        in: RoundedRectangle(cornerRadius: CivicTheme.corner)
                    )
            }

            if engine.showsHandoverQR {
                handoverQRBlock
            }

            if engine.isManualLocationEntry {
                manualLocationInput
            }
        }
    }

    @ViewBuilder
    private var protocolActionsStack: some View {
        Group {
            if engine.currentNode.id == "Type" {
                LazyVGrid(
                    columns: [
                        GridItem(.flexible(), spacing: 12),
                        GridItem(.flexible(), spacing: 12),
                        GridItem(.flexible(), spacing: 12),
                    ],
                    spacing: 12
                ) {
                    ForEach(engine.visibleButtons, id: \.id) { button in
                        typeIconButton(button)
                    }
                }
            } else {
                VStack(spacing: 12) {
                    ForEach(Array(engine.visibleButtons.enumerated()), id: \.element.id) { index, button in
                        actionButton(button, index: index)
                    }
                }
            }
        }
    }

    private var brigadeReportCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(engine.brigadeReportTitle)
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(CivicTheme.ink)

            VStack(alignment: .leading, spacing: 10) {
                ForEach(engine.brigadeReportFields, id: \.id) { field in
                    (
                        Text("\(field.label) — ")
                            .foregroundColor(CivicTheme.muted)
                        + Text(field.value)
                            .foregroundColor(CivicTheme.ink)
                    )
                    .font(.system(size: 20, weight: .semibold))
                    .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            CivicTheme.surface,
            in: RoundedRectangle(cornerRadius: CivicTheme.corner)
        )
        .overlay {
            RoundedRectangle(cornerRadius: CivicTheme.corner)
                .stroke(CivicTheme.border, lineWidth: 1.5)
        }
        .accessibilityElement(children: .combine)
    }

    private var handoverQRBlock: some View {
        VStack(spacing: 10) {
            if let image = QRCodeImage.make(from: engine.handoverQRPayload) {
                Image(uiImage: image)
                    .interpolation(.none)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 280, maxHeight: 280)
                    .padding(12)
                    .background(
                        Color.white,
                        in: RoundedRectangle(cornerRadius: CivicTheme.corner)
                    )
                    .accessibilityLabel(engine.locale == .uk
                                        ? "QR-код звіту для медика"
                                        : "Report QR code for medic")
            } else {
                Text(engine.locale == .uk
                     ? "QR зараз недоступний. Поверніться до звіту."
                     : "QR unavailable. Go back to the report.")
                    .font(.body.weight(.semibold))
                    .foregroundStyle(CivicTheme.muted)
            }
        }
        .frame(maxWidth: .infinity)
    }

    private var manualLocationInput: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                TextField(engine.manualLocationPlaceholder, text: Binding(
                    get: { engine.manualLocationDraft },
                    set: { engine.manualLocationDraft = $0 }
                ))
                .font(.title3.weight(.semibold))
                .textInputAutocapitalization(.words)
                .submitLabel(.next)
                .onSubmit { handle("next") }
                .padding(14)
                .background(
                    CivicTheme.surface,
                    in: RoundedRectangle(cornerRadius: CivicTheme.corner)
                )
                .overlay {
                    RoundedRectangle(cornerRadius: CivicTheme.corner)
                        .stroke(CivicTheme.border, lineWidth: 1.5)
                }

                Button {
                    toggleDictation()
                } label: {
                    Image(systemName: speech.isListening ? "mic.fill" : "mic")
                        .font(.title2.weight(.bold))
                        .foregroundStyle(speech.isListening ? Color.white : CivicTheme.accent)
                        .frame(width: 52, height: 52)
                        .background(
                            speech.isListening ? CivicTheme.danger : CivicTheme.secondaryFill,
                            in: RoundedRectangle(cornerRadius: CivicTheme.buttonCorner)
                        )
                        .overlay {
                            if !speech.isListening {
                                RoundedRectangle(cornerRadius: CivicTheme.buttonCorner)
                                    .stroke(CivicTheme.border, lineWidth: 1.5)
                            }
                        }
                }
                .buttonStyle(.plain)
                .accessibilityLabel(engine.locale == .uk ? "Диктовка" : "Dictate")
            }

            if let error = speech.lastError {
                Text(error)
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(CivicTheme.danger)
            }
        }
    }

    private func toggleDictation() {
        if speech.isListening {
            speech.stopDictation()
            return
        }
        speech.startDictation(locale: engine.locale) { partial in
            engine.manualLocationDraft = partial
        }
    }

    private var screenBackground: Color {
        isVeto ? CivicTheme.vetoCanvas : CivicTheme.canvas
    }

    @ViewBuilder
    private func typeIconButton(_ button: ProtocolButton) -> some View {
        let title = button.title(for: engine.locale)
        Button {
            handle(button.when)
        } label: {
            Color.clear
                .aspectRatio(1, contentMode: .fit)
                .overlay {
                    VStack(spacing: 4) {
                        Spacer(minLength: 0)
                        Image("type_\(button.when)")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 40, maxHeight: 40)
                            .accessibilityHidden(true)

                        Text(title)
                            .font(CivicTheme.typeLabelFont)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(CivicTheme.textPrimary)
                            .lineLimit(2)
                            .minimumScaleFactor(0.65)
                            .frame(maxWidth: .infinity)
                        Spacer(minLength: 0)
                    }
                    .padding(.vertical, 12)
                    .padding(.horizontal, 4)
                }
                .background(
                    CivicTheme.secondaryFill,
                    in: RoundedRectangle(cornerRadius: CivicTheme.buttonCorner)
                )
        }
        .buttonStyle(.plain)
        .accessibilityLabel(title)
    }

    @ViewBuilder
    private func actionButton(_ button: ProtocolButton, index: Int) -> some View {
        let primary = isVeto || (!engine.usesEqualChoiceButtons && index == 0)
        Button {
            handle(button.when)
        } label: {
            Text(button.title(for: engine.locale))
                .font(CivicTheme.buttonFont)
                .multilineTextAlignment(.center)
                .foregroundStyle(buttonInk(primary: primary))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .padding(.horizontal, 14)
                .background(
                    buttonFill(primary: primary),
                    in: RoundedRectangle(cornerRadius: CivicTheme.buttonCorner)
                )
                .overlay {
                    if !primary {
                        RoundedRectangle(cornerRadius: CivicTheme.buttonCorner)
                            .stroke(CivicTheme.border, lineWidth: 1.5)
                    }
                }
        }
        .buttonStyle(.plain)
    }

    private func buttonFill(primary: Bool) -> Color {
        if primary { return CivicTheme.accent }
        return CivicTheme.surface
    }

    private func buttonInk(primary: Bool) -> Color {
        if primary { return .white }
        return CivicTheme.accent
    }

    private var topBar: some View {
        HStack(spacing: 12) {
            Group {
                if engine.canGoBack {
                    Button {
                        engine.goBack()
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "chevron.backward")
                                .font(.body.weight(.bold))
                            Text(engine.locale == .uk ? "Назад" : "Back")
                                .font(.subheadline.weight(.semibold))
                        }
                        .foregroundStyle(CivicTheme.muted)
                    }
                    .buttonStyle(.plain)
                } else {
                    Text("Line 24")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(CivicTheme.ink)
                        .accessibilityAddTraits(.isHeader)
                }
            }
            .frame(minWidth: 88, alignment: .leading)

            Spacer(minLength: 8)

            Button {
                speakOnAppear.toggle()
                AppPreferences.speakOnAppear = speakOnAppear
                if !speakOnAppear {
                    speech.stop()
                }
            } label: {
                Image(systemName: speakOnAppear ? "speaker.wave.2.fill" : "speaker.slash.fill")
                    .foregroundStyle(speakOnAppear ? CivicTheme.success : CivicTheme.accent)
                    .frame(width: 40, height: 40)
                    .background(
                        CivicTheme.secondaryFill,
                        in: RoundedRectangle(cornerRadius: CivicTheme.pillCorner)
                    )
            }
            .buttonStyle(.plain)
            .accessibilityLabel(engine.locale == .uk ? "Голос" : "Voice")

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .foregroundStyle(CivicTheme.accent)
                    .frame(width: 40, height: 40)
                    .background(
                        CivicTheme.secondaryFill,
                        in: RoundedRectangle(cornerRadius: CivicTheme.pillCorner)
                    )
            }
            .buttonStyle(.plain)
            .accessibilityLabel(engine.locale == .uk ? "Налаштування" : "Settings")
        }
        .padding(.horizontal, 20)
        .padding(.top, 16)
        .padding(.bottom, 8)
        .background(screenBackground)
    }

    private func lastEventCard(_ summary: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(summary)
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(CivicTheme.muted)

            Button {
                onOpenLastReport?()
            } label: {
                HStack(spacing: 4) {
                    Text(engine.locale == .uk ? "Відкрити звіт" : "Open report")
                        .font(.system(size: 17, weight: .semibold))
                    Image(systemName: "chevron.forward")
                        .font(.system(size: 13, weight: .semibold))
                }
                .foregroundStyle(CivicTheme.accent)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(engine.locale == .uk ? "Відкрити звіт" : "Open report")
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            CivicTheme.secondaryFill,
            in: RoundedRectangle(cornerRadius: 12)
        )
        .contentShape(RoundedRectangle(cornerRadius: 12))
        .onTapGesture {
            onOpenLastReport?()
        }
        .accessibilityElement(children: .combine)
    }

    private func speakCurrent() {
        guard speakOnAppear else { return }
        speech.speak(engine.voiceText, language: engine.locale.speechLanguageCode)
    }

    private func handle(_ when: String) {
        speech.stopDictation()
        if let onSelect {
            onSelect(when)
            return
        }
        do {
            let result = try engine.select(edgeWhen: when)
            if let url = result.externalURL {
                UIApplication.shared.open(url)
            }
        } catch {
            assertionFailure(String(describing: error))
        }
    }

    private func dial(_ number: String) {
        guard let url = URL(string: "tel:\(number)") else { return }
        UIApplication.shared.open(url)
    }
}

struct EmergencyBar: View {
    var locale: ContentLocale
    var show101: Bool
    var prioritize101: Bool
    var emphasizeCall: Bool
    var onDial: (String) -> Void

    var body: some View {
        VStack(spacing: 0) {
            if prioritize101 {
                Text(locale == .uk
                     ? "Спочатку 101. 103 — якщо є поранені на безпечній відстані"
                     : "101 first. 103 — if casualties are at a safe distance")
                    .font(CivicTheme.emergencyLabel)
                    .foregroundStyle(CivicTheme.muted)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                    .padding(.top, 12)
                    .padding(.bottom, 8)
            }

            if prioritize101, show101 {
                Button {
                    onDial("101")
                } label: {
                    Text(locale == .uk ? "ВИКЛИКАТИ 101 (ДСНС)" : "CALL 101 (rescue)")
                        .font(CivicTheme.emergencyTitle)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, contentVerticalPadding)
                        .background(CivicTheme.danger)
                }
                .buttonStyle(.plain)

                Button {
                    onDial("103")
                } label: {
                    Text(locale == .uk ? "Викликати 103" : "Call 103")
                        .font(.body.weight(.bold))
                        .foregroundStyle(CivicTheme.danger)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, secondaryVerticalPadding)
                        .padding(.bottom, bottomSafePadding)
                        .frame(maxWidth: .infinity)
                        .background(CivicTheme.canvas.ignoresSafeArea(edges: .bottom))
                        .overlay(alignment: .top) {
                            Rectangle()
                                .fill(CivicTheme.antiBorder)
                                .frame(height: 1)
                        }
                }
                .buttonStyle(.plain)
            } else {
                Button {
                    onDial("103")
                } label: {
                    Text(locale == .uk ? "ВИКЛИКАТИ 103" : "CALL 103")
                        .font(CivicTheme.emergencyTitle)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.top, primaryBarTopPadding)
                        .padding(.bottom, primaryBarBottomPadding)
                        .frame(maxWidth: .infinity)
                        .background(
                            CivicTheme.danger.ignoresSafeArea(edges: show101 ? [] : .bottom)
                        )
                }
                .buttonStyle(.plain)

                if show101 {
                    Button {
                        onDial("101")
                    } label: {
                        Text(locale == .uk ? "Викликати 101 (ДСНС)" : "Call 101 (rescue)")
                            .font(.body.weight(.bold))
                            .foregroundStyle(CivicTheme.accent)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, secondaryVerticalPadding)
                            .padding(.bottom, bottomSafePadding)
                            .frame(maxWidth: .infinity)
                            .background(
                                CivicTheme.secondaryFill.ignoresSafeArea(edges: .bottom)
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    /// Extra tap padding into the home-indicator area; 0 on iPhone 7 / devices without inset.
    private var bottomSafePadding: CGFloat {
        let inset = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap(\.windows)
            .first(where: \.isKeyWindow)?
            .safeAreaInsets.bottom ?? 0
        return max(inset, 0)
    }

    /// On home-indicator phones the safe-area fill already adds height — keep content padding tighter.
    private var hasHomeIndicator: Bool { bottomSafePadding > 0 }

    private var contentVerticalPadding: CGFloat { hasHomeIndicator ? 14 : 22 }

    private var emphasizedVerticalPadding: CGFloat { hasHomeIndicator ? 16 : 26 }

    private var secondaryVerticalPadding: CGFloat { hasHomeIndicator ? 12 : 16 }

    /// Extra top inset so the label sits a bit lower inside the tall safe-area bar.
    private var primaryBarTopPadding: CGFloat {
        let base = emphasizeCall ? emphasizedVerticalPadding : contentVerticalPadding
        return base + (hasHomeIndicator && !show101 ? 10 : 0)
    }

    private var primaryBarBottomPadding: CGFloat {
        let base = emphasizeCall ? emphasizedVerticalPadding : contentVerticalPadding
        return base + (show101 ? 0 : bottomSafePadding)
    }
}

enum QRCodeImage {
    static func make(from string: String, scale: CGFloat = 10) -> UIImage? {
        let data = Data(string.utf8)
        guard let filter = CIFilter(name: "CIQRCodeGenerator") else { return nil }
        filter.setValue(data, forKey: "inputMessage")
        filter.setValue("M", forKey: "inputCorrectionLevel")
        guard let output = filter.outputImage else { return nil }
        let transformed = output.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        let context = CIContext()
        guard let cgImage = context.createCGImage(transformed, from: transformed.extent) else {
            return nil
        }
        return UIImage(cgImage: cgImage)
    }
}
